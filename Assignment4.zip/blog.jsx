<>
    <title />
    <meta charSet="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway" />
    <style dangerouslySetInnerHTML={{__html: "\n    body,h1,h2,h3,h4,h5 {font-family: \"Raleway\", sans-serif}\n" }} />
    {/* w3-content defines a container for fixed size centered content,
and is wrapped around the whole page content, except for the footer in this example */}
    <div className="w3-content" style={{maxWidth: 1400}}>
        {/* Header */}
        <header className="w3-container w3-center w3-padding-32">
            <h1><b>MY BLOG</b></h1>
            <p>Welcome to the blog of <span className="w3-tag">Meher</span></p>
        </header>
        {/* Grid */}
        <div className="w3-row">
            {/* Blog entries */}
            <div className="w3-col l8 s12">
                <div className="w3-card-4 w3-margin w3-white">
                    <div className="w3-container">
                        {/* Title entry */}
                        <h3><b><a href="https://mailchi.mp/pace/blue_team_bulletin_5"> Blue CoLab Team Bulletin #5</a></b></h3>
                        {/* Date entry */}
                        <h5>Date, <span className="w3-opacity">11/10/2020</span></h5>
                    </div>
                    {/* Summary entry */}
                    <div className="w3-container">
                        <img src="Capture.JPG" alt="Nature" style={{width: '100%'}} />
                        <p>Summary :
                            Let Ada Sing!
                            By Meher Upadhyay, MS x'21
                            Software Engineer/Sonification Lead
                            Choate Pond = Narragansett Bay?
                            By Justin Brandon '21
                            Lead Field Technician
                        </p>
                    </div>
                </div>
                <hr />
                {/* Blog entry */}
                <div className="w3-card-4 w3-margin w3-white">
                    <div className="w3-container">
                        {/* Title entry */}
                        <h3><b><a href="https://us17.campaign-archive.com/?u=1ae22385c18dbc664ae75c056&id=a656d9589c"> Blue CoLab Team Bulletin #4</a></b></h3>
                        {/* Date entry */}
                        <h5>Date, <span className="w3-opacity">10/23/2020</span></h5>
                    </div>
                    {/* Summary entry */}
                    <div className="w3-container">
                        <img src="Capture1.JPG" alt="Nature" style={{width: '100%'}} />
                        <p>Summary: Team Taming iOS and Android
                            By Ophelia Mendoza '22
                            Head iOS/Android Developer
                            A Choate Pond Water Quality Index
                            By Vanessa Armstrong, MSx'21
                            Chief Water Quality Analyst
                        </p>
                    </div>
                </div>
                <hr />
                {/* Blog entry */}
                <div className="w3-card-4 w3-margin w3-white">
                    <div className="w3-container">
                        {/* Title entry */}
                        <h3><b><a href="https://us17.campaign-archive.com/?u=1ae22385c18dbc664ae75c056&id=f75c2822b9"> Blue CoLab Team Bulletin #3</a></b></h3>
                        {/* Date entry */}
                        <h5>Date, <span className="w3-opacity">10/12/2020</span></h5>
                    </div>
                    {/* Summary entry */}
                    <div className="w3-container">
                        <img src="Capture3.JPG" alt="Nature" style={{width: '100%'}} />
                        <p>Summary: The Power of
                            Invisible Design
                            By Gabrielle Martinez
                            Lead Designer for Art Direction
                            Dr. Parisi Meets the Data Analytics Team
                            By Vicente Gomez
                            Senior Data Scientist and Team Lead
                        </p>
                    </div>
                </div>
                <hr />
                {/* END BLOG ENTRIES */}
            </div>
            {/* Introduction menu */}
            <div className="w3-col l4">
                {/* Google Posts */}
                <div className="w3-card w3-margin">
                    <div className="w3-container w3-padding">
                        <h4>Popular Google Posts</h4>
                    </div>
                    <ul className="w3-ul w3-hoverable w3-white">
                        <li className="w3-padding-16">
                            <img src="https://d.newsweek.com/en/full/1674338/trump.webp?w=790&f=0f928c49df8b0df073d63676d9f8fd0d" alt="Image" className="w3-left w3-margin-right" style={{width: 50}} />
                            <h3><b><a href="https://www.newsweek.com/trump-yet-answer-one-press-question-since-election-gop-pressure-his-concession-biden-grows-1549366">here</a></b></h3>
                        </li>
                        <li className="w3-padding-16">
                            <img src="https://d.newsweek.com/en/full/1674338/trump.webp?w=790&f=0f928c49df8b0df073d63676d9f8fd0d" alt="Image" className="w3-left w3-margin-right" style={{width: 50}} />
                            <h3><b><a href="https://www.nytimes.com/2020/11/22/us/politics/biden-antony-blinken-secretary-of-state.html">here</a></b></h3>
                        </li>
                        <li className="w3-padding-16">
                            <img src="https://static01.nyt.com/images/2020/11/23/us/politics/00dc-state-blinken-print/merlin_179822205_c7163a55-8518-42d3-a90f-11d21aa5e9fa-jumbo.jpg?quality=90&auto=webp" style={{width: 50}} />
                            <h3><b><a href="https://www.foxnews.com/politics/chris-christie-trump-legal-team-national-embarrassment">here</a></b></h3>
                        </li>
                        <li className="w3-padding-16 w3-hide-medium w3-hide-small">
                            <img src="https://d.newsweek.com/en/full/1674338/trump.webp?w=790&f=0f928c49df8b0df073d63676d9f8fd0d" alt="Image" className="w3-left w3-margin-right" style={{width: 50}} />
                            <h3><b><a href="https://www.newsweek.com/trump-yet-answer-one-press-question-since-election-gop-pressure-his-concession-biden-grows-1549366">here</a></b></h3>
                        </li>
                        <li className="w3-padding-16 w3-hide-medium w3-hide-small">
                            <img src="https://d.newsweek.com/en/full/1674338/trump.webp?w=790&f=0f928c49df8b0df073d63676d9f8fd0d" alt="Image" className="w3-left w3-margin-right" style={{width: 50}} />
                            <h3><b><a href="https://www.newsweek.com/trump-yet-answer-one-press-question-since-election-gop-pressure-his-concession-biden-grows-1549366">here</a></b></h3>
                        </li>
                    </ul>
                </div>
                <hr />
                {/* Twitter Posts */}
                <div className="w3-card w3-margin">
                    <div className="w3-container w3-padding">
                        <h4>Popular Twitter Posts</h4>
                    </div>
                    <ul className="w3-ul w3-hoverable w3-white">
                        <li className="w3-padding-16">
                            <img src="https://pbs.twimg.com/semantic_core_img/1325119626116648960/DYBVmJEf?format=jpg&name=small" alt="Image" className="w3-left w3-margin-right" style={{width: 50}} />
                            <h3><b><a href="https://twitter.com/i/events/1318573265820921857">here</a></b></h3>
                        </li>
                        <li className="w3-padding-16">
                            <img src="https://d.newsweek.com/en/full/1674338/trump.webp?w=790&f=0f928c49df8b0df073d63676d9f8fd0d" alt="Image" className="w3-left w3-margin-right" style={{width: 50}} />
                            <h3><b><a href="https://www.newsweek.com/trump-yet-answer-one-press-question-since-election-gop-pressure-his-concession-biden-grows-1549366">here</a></b></h3>
                        </li>
                        <li className="w3-padding-16">
                            <img src="https://pbs.twimg.com/profile_banners/2467791/1469484132/600x200" style={{width: 50}} />
                            <h3><b><a href="https://twitter.com/washingtonpost">here</a></b></h3>
                        </li>
                        <li className="w3-padding-16 w3-hide-medium w3-hide-small">
                            <img src="https://pbs.twimg.com/profile_banners/18650093/1604950691/600x200" alt="Image" className="w3-left w3-margin-right" style={{width: 50}} />
                            <h3><b><a href="https://twitter.com/pressfreedom">here</a></b></h3>
                        </li>
                        <li className="w3-padding-16 w3-hide-medium w3-hide-small">
                            <img src="https://pbs.twimg.com/profile_banners/28785486/1505493568/600x200" alt="Image" className="w3-left w3-margin-right" style={{width: 50}} />
                            <h3><b><a href="https://twitter.com/ABC">here</a></b></h3>
                        </li>
                    </ul>
                </div>
                <hr />
                {/* END Introduction Menu */}
            </div>
            {/* END GRID */}
        </div><br />
        {/* END w3-content */}
    </div>
    {/* Footer */}
    <footer className="w3-container w3-dark-grey w3-padding-32 w3-margin-top">
    </footer>
</>
